# Soil detection > 2023-08-16 11:19pm
https://universe.roboflow.com/imit-h5ows/soil-detection-l0ngo

Provided by a Roboflow user
License: CC BY 4.0

